var searchData=
[
  ['move_0',['Move',['../d8/da6/namespaceQMdmmCore_1_1Data.html#a461e2f0a2b58ce711e7067363754c6ffa2669b868ad6e1c5e09d458c298ed961d',1,'QMdmmCore::Data']]]
];
