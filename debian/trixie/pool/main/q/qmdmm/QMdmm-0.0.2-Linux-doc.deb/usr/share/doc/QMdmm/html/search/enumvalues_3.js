var searchData=
[
  ['global_0',['Global',['../d6/d5a/classQMdmmCore_1_1Settings.html#ac62739838e733be5d3af69cba613fc41a6ea8590f45b637d78914900379de4df7',1,'QMdmmCore::Settings']]]
];
