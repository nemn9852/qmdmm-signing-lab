var searchData=
[
  ['damagereasonunknown_0',['DamageReasonUnknown',['../d8/da6/namespaceQMdmmCore_1_1Data.html#a550a7c09c7ce7f41a308642880178040a10112b33b7372c40c2e2c40b5dd1c3b1',1,'QMdmmCore::Data']]],
  ['donothing_1',['DoNothing',['../d8/da6/namespaceQMdmmCore_1_1Data.html#a461e2f0a2b58ce711e7067363754c6ffa956f9e0e5bad7755c5a897a23bd7c5cd',1,'QMdmmCore::Data']]]
];
