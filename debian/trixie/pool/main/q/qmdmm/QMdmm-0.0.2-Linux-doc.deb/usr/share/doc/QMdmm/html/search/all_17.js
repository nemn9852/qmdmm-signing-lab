var searchData=
[
  ['zerohpasdead_0',['zerohpasdead',['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#a10c0b6880ae259dee5b3fa123e72fae4',1,'QMdmmCore::LogicConfiguration::zeroHpAsDead'],['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#ab7ee8681b1a457766ef2651acaf6d2da',1,'QMdmmCore::LogicConfiguration::zeroHpAsDead() const']]]
];
