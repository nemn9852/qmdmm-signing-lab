var searchData=
[
  ['game_0',['The game',['../index.html#autotoc_md1',1,'']]],
  ['game_20bots_1',['Play a headless game (bots)',['../d1/dce/md_getting-started.html#autotoc_md32',1,'']]],
  ['game_20runs_2',['The programs a local game runs',['../d1/dce/md_getting-started.html#autotoc_md31',1,'']]],
  ['gameover_3',['gameover',['../d7/dd6/classQMdmmCore_1_1Logic.html#a1a0a11ee662b60633920940e8888ca7e',1,'QMdmmCore::Logic::gameOver()'],['../da/d9f/classQMdmmNetworking_1_1LogicRunner.html#a0f16211c1f27b1f044196bea47c60815',1,'QMdmmNetworking::LogicRunner::gameOver()']]],
  ['gameovernotified_4',['gameOverNotified',['../d8/dec/classQMdmmNetworking_1_1Agent.html#a605e438198cf3aa6fb6958612afa3a15',1,'QMdmmNetworking::Agent']]],
  ['gamestartnotified_5',['gameStartNotified',['../d8/dec/classQMdmmNetworking_1_1Agent.html#aa5e32c322a5178edca23dd28711b3ab7',1,'QMdmmNetworking::Agent']]],
  ['getting_20started_6',['Getting Started',['../d1/dce/md_getting-started.html',1,'']]],
  ['giveuprequest_7',['giveUpRequest',['../d8/dec/classQMdmmNetworking_1_1Agent.html#ab1252b1cfc09dc9b747deca2e6a713e3',1,'QMdmmNetworking::Agent']]],
  ['global_8',['Global',['../d6/d5a/classQMdmmCore_1_1Settings.html#ac62739838e733be5d3af69cba613fc41a6ea8590f45b637d78914900379de4df7',1,'QMdmmCore::Settings']]],
  ['gui_9',['Run a client (GUI)',['../d1/dce/md_getting-started.html#autotoc_md30',1,'']]]
];
