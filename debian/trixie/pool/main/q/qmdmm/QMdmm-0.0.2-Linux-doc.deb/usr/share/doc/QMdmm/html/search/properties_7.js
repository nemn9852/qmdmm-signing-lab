var searchData=
[
  ['localenabled_0',['localEnabled',['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#a40f2c4b00a315145445149974c140229',1,'QMdmmNetworking::ServerConfiguration']]],
  ['localsocketname_1',['localSocketName',['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#a5288e7e84650c03833f0838adaa54bb7',1,'QMdmmNetworking::ServerConfiguration']]]
];
