var searchData=
[
  ['village_0',['Village',['../d8/da6/namespaceQMdmmCore_1_1Data.html#a9e0e8b35ac8bf040bb8473b33a7bbb2dab059dc21bce74bc98ed26d7545d0e008',1,'QMdmmCore::Data']]]
];
