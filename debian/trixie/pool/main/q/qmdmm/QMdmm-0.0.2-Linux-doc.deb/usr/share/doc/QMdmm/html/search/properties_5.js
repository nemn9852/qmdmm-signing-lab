var searchData=
[
  ['initialhorsedamage_0',['initialHorseDamage',['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#a0cf7aaa4400c82ca63009c246488d113',1,'QMdmmCore::LogicConfiguration']]],
  ['initialknifedamage_1',['initialKnifeDamage',['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#aad39e9c0baca4f8a2116c67316e34a64',1,'QMdmmCore::LogicConfiguration']]],
  ['initialmaxhp_2',['initialMaxHp',['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#a1f2042a7ccb150143094f674dbcf95e2',1,'QMdmmCore::LogicConfiguration']]],
  ['initialplace_3',['initialPlace',['../d2/d1a/classQMdmmCore_1_1Player.html#a41a2757902cd7a502e1318c48222333b',1,'QMdmmCore::Player']]]
];
