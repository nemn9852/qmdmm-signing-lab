var searchData=
[
  ['canbuyonlyininitialcity_0',['canBuyOnlyInInitialCity',['../dc/db8/classQMdmmCore_1_1LogicConfiguration.html#af628e661fd573aad214a48454d789112',1,'QMdmmCore::LogicConfiguration']]]
];
