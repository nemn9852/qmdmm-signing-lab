var searchData=
[
  ['started_0',['Getting Started',['../d1/dce/md_getting-started.html',1,'']]]
];
