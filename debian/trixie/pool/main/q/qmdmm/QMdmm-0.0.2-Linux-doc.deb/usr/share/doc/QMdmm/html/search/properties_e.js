var searchData=
[
  ['websocketenabled_0',['websocketEnabled',['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#a1fe135c77ca9d23c3c20ca4b88ebc0c4',1,'QMdmmNetworking::ServerConfiguration']]],
  ['websocketname_1',['websocketName',['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#a3f8de0c7d20288dc6304457a59cde5f4',1,'QMdmmNetworking::ServerConfiguration']]],
  ['websocketport_2',['websocketPort',['../d8/d03/structQMdmmNetworking_1_1ServerConfiguration.html#a0fb5f3f77476d747913c6e27d02a5776',1,'QMdmmNetworking::ServerConfiguration']]]
];
